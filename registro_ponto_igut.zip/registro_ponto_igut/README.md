# Registro Automático de Ponto - IGUT

Bot em Python para registrar ponto automaticamente no IGUT da sua clínica.

## ⚙️ Como utilizar

1. Crie um arquivo `.env` baseado no `.env.example` com seus dados:
   ```
   CLINICA=...
   USUARIO=...
   SENHA=...
   ```

2. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```

3. Execute o script:
   ```bash
   python main.py
   ```

4. Hospede em Replit, VPS ou similar para rodar 24/7. Para manter online, use serviço tipo UptimeRobot.

## 🕒 Horários agendados
- Entrada: 08:00
- Almoço: 12:00
- Retorno: 13:00
- Saída: 18:00
