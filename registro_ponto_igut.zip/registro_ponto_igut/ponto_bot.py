import os
import time
from dotenv import load_dotenv
from selenium.webdriver.common.by import By
from utils.navegador import criar_navegador

load_dotenv()

def registrar_ponto():
    try:
        driver = criar_navegador()
        driver.get("https://externo.igutclinicas.com.br/mobile/#pontomedico")
        time.sleep(3)

        driver.find_element(By.ID, "empresa").send_keys(os.getenv("CLINICA"))
        driver.find_element(By.ID, "usuario").send_keys(os.getenv("USUARIO"))
        driver.find_element(By.ID, "senha").send_keys(os.getenv("SENHA"))
        driver.find_element(By.XPATH, "//button[contains(text(), 'Entrar')]").click()
        time.sleep(3)

        driver.find_element(By.XPATH, "//button[contains(text(), 'REGISTRAR')]").click()
        print("✅ Ponto registrado com sucesso!")

    except Exception as e:
        print(f"❌ Erro ao registrar ponto: {e}")
    finally:
        driver.quit()
