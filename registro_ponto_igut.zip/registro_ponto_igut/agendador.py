import schedule
import time
from ponto_bot import registrar_ponto

# Configure aqui os seus horários de registro
HORARIOS = ["08:00", "12:00", "13:00", "18:00"]

for h in HORARIOS:
    schedule.every().day.at(h).do(registrar_ponto)

def rodar_agendador():
    while True:
        schedule.run_pending()
        time.sleep(30)
