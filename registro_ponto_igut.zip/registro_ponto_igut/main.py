from agendador import rodar_agendador

if __name__ == "__main__":
    print("📅 Sistema de ponto automático iniciado.")
    rodar_agendador()
